package pk.edu.iqra.firstapp.utils

object DataHolder {
    lateinit var customer: Customer
}