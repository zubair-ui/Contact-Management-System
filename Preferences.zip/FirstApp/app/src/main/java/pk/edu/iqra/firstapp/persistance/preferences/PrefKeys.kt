package pk.edu.iqra.firstapp.persistance.preferences

object PrefKeys {
    val COUNTER = "counter"
    val CUSTOMER = "customer"
    val CUSTOMER_LIST = "customer_list"
}