package pk.edu.iqra.cms;

@androidx.databinding.BindingBuildInfo
public class DataBindingTriggerClass {}