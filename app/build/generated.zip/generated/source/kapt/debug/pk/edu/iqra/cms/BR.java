package pk.edu.iqra.cms;

public class BR {
  public static final int _all = 0;
}
