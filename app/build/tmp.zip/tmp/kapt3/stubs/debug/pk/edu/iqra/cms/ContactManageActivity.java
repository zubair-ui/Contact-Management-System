package pk.edu.iqra.cms;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\t\u001a\u00020\nJ\u0012\u0010\u000b\u001a\u00020\n2\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0014J\u000e\u0010\u000e\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u0010J\n\u0010\u0011\u001a\u00020\u0010*\u00020\u0012R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0013"}, d2 = {"Lpk/edu/iqra/cms/ContactManageActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "binding", "Lpk/edu/iqra/cms/databinding/ActivityContactManageBinding;", "coroutineScope", "Lkotlinx/coroutines/CoroutineScope;", "uContact", "Lpk/edu/iqra/cms/database/Contact;", "handleContact", "", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "showToastMessage", "message", "", "getUIText", "Landroid/widget/EditText;", "app_debug"})
public final class ContactManageActivity extends androidx.appcompat.app.AppCompatActivity {
    private pk.edu.iqra.cms.databinding.ActivityContactManageBinding binding;
    @org.jetbrains.annotations.NotNull
    private final kotlinx.coroutines.CoroutineScope coroutineScope = null;
    @org.jetbrains.annotations.Nullable
    private pk.edu.iqra.cms.database.Contact uContact;
    
    public ContactManageActivity() {
        super();
    }
    
    @java.lang.Override
    protected void onCreate(@org.jetbrains.annotations.Nullable
    android.os.Bundle savedInstanceState) {
    }
    
    public final void handleContact() {
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.lang.String getUIText(@org.jetbrains.annotations.NotNull
    android.widget.EditText $this$getUIText) {
        return null;
    }
    
    public final void showToastMessage(@org.jetbrains.annotations.NotNull
    java.lang.String message) {
    }
}