package pk.edu.iqra.cms.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\b\u00a8\u0006\t"}, d2 = {"Lpk/edu/iqra/cms/utils/DataHolder;", "", "()V", "contact", "Lpk/edu/iqra/cms/database/Contact;", "getContact", "()Lpk/edu/iqra/cms/database/Contact;", "setContact", "(Lpk/edu/iqra/cms/database/Contact;)V", "app_debug"})
public final class DataHolder {
    @org.jetbrains.annotations.Nullable
    private static pk.edu.iqra.cms.database.Contact contact;
    @org.jetbrains.annotations.NotNull
    public static final pk.edu.iqra.cms.utils.DataHolder INSTANCE = null;
    
    private DataHolder() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable
    public final pk.edu.iqra.cms.database.Contact getContact() {
        return null;
    }
    
    public final void setContact(@org.jetbrains.annotations.Nullable
    pk.edu.iqra.cms.database.Contact p0) {
    }
}