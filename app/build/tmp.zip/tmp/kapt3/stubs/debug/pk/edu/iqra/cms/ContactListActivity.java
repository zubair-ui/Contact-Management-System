package pk.edu.iqra.cms;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u00012\u00020\u0002B\u0005\u00a2\u0006\u0002\u0010\u0003J\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\tJ\u0006\u0010\u000e\u001a\u00020\tJ\u0010\u0010\u000f\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\fH\u0016J\u0012\u0010\u0010\u001a\u00020\t2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0014J\b\u0010\u0013\u001a\u00020\tH\u0014J\u0006\u0010\u0014\u001a\u00020\tJ\u000e\u0010\u0015\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"}, d2 = {"Lpk/edu/iqra/cms/ContactListActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "Lpk/edu/iqra/cms/listener/ListAction;", "()V", "adapter", "Lpk/edu/iqra/cms/adapter/ContactAdapter;", "binding", "Lpk/edu/iqra/cms/databinding/ActivityContactListBinding;", "addContact", "", "deleteContact", "contact", "Lpk/edu/iqra/cms/database/Contact;", "initializeRV", "navigate", "onClick", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onResume", "refreshList", "updateContact", "app_debug"})
public final class ContactListActivity extends androidx.appcompat.app.AppCompatActivity implements pk.edu.iqra.cms.listener.ListAction {
    private pk.edu.iqra.cms.databinding.ActivityContactListBinding binding;
    private pk.edu.iqra.cms.adapter.ContactAdapter adapter;
    
    public ContactListActivity() {
        super();
    }
    
    @java.lang.Override
    protected void onCreate(@org.jetbrains.annotations.Nullable
    android.os.Bundle savedInstanceState) {
    }
    
    public final void initializeRV() {
    }
    
    @java.lang.Override
    protected void onResume() {
    }
    
    public final void refreshList() {
    }
    
    @java.lang.Override
    public void onClick(@org.jetbrains.annotations.NotNull
    pk.edu.iqra.cms.database.Contact contact) {
    }
    
    public final void addContact() {
    }
    
    public final void updateContact(@org.jetbrains.annotations.NotNull
    pk.edu.iqra.cms.database.Contact contact) {
    }
    
    public final void navigate() {
    }
    
    public final void deleteContact(@org.jetbrains.annotations.NotNull
    pk.edu.iqra.cms.database.Contact contact) {
    }
}